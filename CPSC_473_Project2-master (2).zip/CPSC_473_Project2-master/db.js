module.exports = {
	//'url' : 'mongodb://<dbuser>:<dbpassword>@novus.modulusmongo.net:27017/<dbName>'
	'url' : 'mongodb://kuldeep:harshal1991@ds015902.mlab.com:15902/473project2'
}
