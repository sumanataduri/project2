var LocalStrategy   = require('passport-local').Strategy;
var User = require('../models/quiz');
var bCrypt = require('bcrypt-nodejs');

module.exports = function(passport){

	passport.use('quiz', new LocalStrategy({
            passReqToCallback : true
        },
        function(req, username, password, done) {

             Quiz.find({}, function(err, values) {
                    if (err){
                        console.log('Error in getting value from database: '+err);
                        return done(err);
                    }
                     else {
                        console.log(values);
                        return done(null,values);

                    }
                });
             })
    );

}