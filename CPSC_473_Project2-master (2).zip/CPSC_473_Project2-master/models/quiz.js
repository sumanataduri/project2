var mongoose = require('mongoose');

module.exports = mongoose.model('Quiz',{

    username: String,
    category: String,
    questionsData:[ {
        id: Number,
        questions:String,
        options: [String],
        answer: String
    } ,
    {
        id: Number,
        questions:String,
        options: [String],
        answer: String
    },
    {
        id: Number,
        questions:String,
        options: [String],
        answer: String
    },
    {
        id: Number,
        questions:String,
        options: [String],
        answer: String
    } 
    ]	

});
